import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rmessage',
  templateUrl: './rmessage.component.html',
  styleUrls: ['./rmessage.component.css']
})
export class RmessageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
