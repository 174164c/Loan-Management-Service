import { identifierModuleUrl } from "@angular/compiler";

export class Cus{
    id:Number;
    name: string;
    username: string;
    email: string;
    password: string;
   roles:any;
}


