export class Announce {
    id:Number;
    aname:String;
    message: string;
    date: string;

}