export class Puser {
    id:Number;
    uid:Number;
    uname:String;
    name: string;
    minage: string;
    minsalary: string;
    about: string;
}