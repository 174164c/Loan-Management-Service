export class Iguser {
    id:Number;
    uid:Number;
    uname:String;
    name: string;
    username: string;
    email: string;
    password: string;
}