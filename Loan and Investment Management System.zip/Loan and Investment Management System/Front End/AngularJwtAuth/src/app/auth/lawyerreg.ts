export class Lawyerreg {
    
    name: string;
    contactnum: string;
    email: string;
    address: string;
    town: string;


    constructor( name: string, contactnum: string, email: string, address: string, town: string) {
      
        this.name = name;
        this.contactnum = contactnum;
        this.email = email;
        this.address = address;
        this.town = town;

    }
}
