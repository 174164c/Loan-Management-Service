export class AnnounceReg {
   
    aname:String;
    message: string;
    date: string;

    constructor(aname:string, message: string,date: string) {
  
        this.aname=aname;
        this.message =message;
        this.date=date;
    }
}
