export class Luser {
  id:number;
  name: string;
  dateofbirth:Date;
  nic: string;
  address: string;
  mobilenum: string;
  profession: string;
  username: string;
  email: string;
  roles:any;
  password: string;
  
  }
  


