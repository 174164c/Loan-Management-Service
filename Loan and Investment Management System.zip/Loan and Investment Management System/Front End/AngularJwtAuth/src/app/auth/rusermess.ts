export class Rusermess {
    fromuname:String;
    touname:String;
    uname:String;
    name: string;
    date: string;

    constructor( fromuname:String, touname:String,uname:string, name: string,date: string) {
        this.fromuname=fromuname;
        this.touname=touname;
        this.uname=uname;
        this.name = name;
        this.date=date;
 
    }
}
