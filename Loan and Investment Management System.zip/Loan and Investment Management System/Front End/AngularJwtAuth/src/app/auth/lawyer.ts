export class Lawyer {
    id:Number;
    name: string;
    contactnum: string;
    email: string;
    address: string;
    town: string;

}