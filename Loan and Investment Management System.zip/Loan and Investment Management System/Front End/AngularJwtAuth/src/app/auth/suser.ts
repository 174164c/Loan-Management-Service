export class Suser {
    id:Number;
    uid:Number;
    uname:String;
    name: string;
    username: string;
    email: string;
    password: string;
}